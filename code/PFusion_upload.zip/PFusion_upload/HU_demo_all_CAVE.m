%clc;
clear; close all;
addpath('assess_fold','utils')
%% load mask / image
% load the image;
%load the mask (the size size of image) for the CASSI measurements
% Load A for the RGB measurements
load Toy.mat 
%%
[M,N,B] = size(orig);
% parameters
ma = 3;  %% spectral band of RGB
mb = 1;  %% spectral band of CASSI
p = ma;  %% subspace
%% reconstruction
[RGB, meas] = HU_Coder(orig, mask, A);
tic 
[rec_img] = HU_patch_process(RGB,meas, mask,p);
%[rec_img] = HU_Decoder(RGB,meas, mask,p);
t = toc
%% evaluation
[PSNR,SSIM,SAM,MQresult] = evaluate(orig,rec_img,M,N);
PSNR = mean(PSNR);SSIM = mean(SSIM);SAM = mean(SAM);
fprintf( 'PSNR = %2.2f, SSIM = %2.3f \n', PSNR, SSIM);