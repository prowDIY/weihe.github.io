function  [Rec_im, PSNR, SSIM]    =  HSImage_CS(ori_im, rate)
randn('state',0);
rand('state',0);
%% compression encoder
sz =  size(ori_im);
ori_im  =  reshape(ori_im, sz(1) * sz(2), sz(3));
par               =    Set_parameters(rate);
[A, At, P]        =    Compressive_sensing(ori_im, rate);
par.picks         =    P;
par.y             =    A(ori_im(:));
par.ori_im        =    ori_im;   % For computing PSNR only
par.sz = sz;
disp( sprintf('The sensing rate: %f\n', length(P)/(prod(size(ori_im)))) );
%% reconsturction decoder
[Rec_im PSNR SSIM]      =   NGmeet_Reconstruction( par, rate, A, At ); 
return;


function [A, At, P]   =  Compressive_sensing(im, rate)

    [A, At, P]    =  Random_Sensing(im, rate);

return;

function [A, At, P]   =  Random_Sensing(im, rate)
rand('seed',0);
[h w ch]     =    size(im);

    N            =    h*w;
    K            =    round( N*rate );
    P            =    randperm(N)';
    q            =    randperm(N/2-1)+1;
    OMEGA        =    q(1:ceil(K))';
    A            =    @(z) A_f(z, OMEGA, P);
    At           =    @(z) At_f(z, N, OMEGA, P);
    P            =    OMEGA;

return;

