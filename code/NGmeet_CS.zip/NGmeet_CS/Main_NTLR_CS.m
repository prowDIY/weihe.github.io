
clc;
clear;
addpath('Measurements');
addpath('lib');
addpath('my_toolbox');

rates     =    [0.02, 0.05, 0.10, 0.15, 0.2];
idx       =    3;

load Toy.mat

%% chart_and_stuffed_toy_ms

ori_im = double(Toy(151:450,171:470,:));

[h, w, b] =  size(ori_im);
ori_im  =  reshape(ori_im, h * w, b);
Rec_im  =  HSImage_CS(ori_im, rates(idx));
Rec_im  =  reshape(Rec_im, h, w, b);

%save Results_010.mat Rec_im



