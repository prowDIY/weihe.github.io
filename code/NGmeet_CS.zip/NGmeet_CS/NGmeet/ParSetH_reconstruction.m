function  [par]=ParSetH_reconstruction(nSig,band,ratio)
%Pavia with 0.1 noise : par.SearchWin 40, par.c1=5*sqrt(2); par.Iter=   5;
%par.rho     = 10; par.lambda = 0.1; par.patnum   =   200;
% toy data par.SearchWin = 30;  par.patnum =120; Other,
% WDC the same as Pavia data but with par.patnum 120
% the setting of par.SearchWin, par.c1 and par.step, par.patsize par.Iter
% par.lamada par.patnum are from LLRT, par.k_subspace is estimated by
% HySime
%% Patch-based Iteration Parameters
par.nSig        =   nSig;                               % Variance of the noise image
par.SearchWin   =   30;                                 % Non-local patch searching window
par.c1          =  5*sqrt(2);                           % Constant num for HSI
par.step     = 4;                                       % stepsize
%% Patch and noise Parameters
if band<=50
if ratio<=0.021
    par.patsize       =   5;
    par.patnum        =   160;                  
    par.Iter          =   50;
    par.lamada        =   0.56;
    par.k_subspace  = 3;
    par.nSig        = 15;
elseif ratio <= 0.051
    par.patsize       =   5;
    par.patnum        =   160;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 4;
    par.nSig        = 15;
elseif ratio <= 0.11
    par.patsize       =   5;
    par.patnum        =   140;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 8;
elseif ratio <=0.151
    par.patsize       =   5;
    par.patnum        =   100;
    par.Iter          =   30;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 5;
else
    par.patsize       =   5;
    par.patnum        =   150;
    par.Iter          =   20;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 5;
end
%%%%%%%%%%%%%%%%%%
elseif band<=100
if ratio<=0.021
    par.patsize       =   5;
    par.patnum        =   160;                  
    par.Iter          =   50;
    par.lamada        =   0.56;
    par.k_subspace  = 4;
    par.nSig        = 15;
elseif ratio <= 0.051
    par.patsize       =   5;
    par.patnum        =   150;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 10;
elseif ratio <= 0.11
    par.patsize       =   5;
    par.patnum        =   150;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 10;
elseif ratio <=0.151
    par.patsize       =   5;
    par.patnum        =   150;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 10;
else
    par.patsize       =   5;
    par.patnum        =   150;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 7;
end
  %%%%%%%%%%%%%%%%%%  
elseif band<=250
   par.c1          =  8*sqrt(2);                           % Constant num for HSI
if ratio<=0.021
    par.patsize       =   5;
    par.patnum        =   160;                  
    par.Iter          =   80;
    par.lamada        =   0.56;
    par.k_subspace  = 3;
    par.nSig        = 15;
elseif ratio <= 0.051
    par.patsize       =   5;
    par.patnum        =   150;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 15;
elseif ratio <= 0.11
    par.patsize       =   5;
    par.patnum        =   100;%150
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 10;
elseif ratio <=0.151
    par.patsize       =   5;
    par.patnum        =   100;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 10;
else
    par.patsize       =   5;
    par.patnum        =   100;
    par.Iter          =   50;
    par.lamada        =   0.56; 
    par.k_subspace  = 5;
    par.nSig        = 10;
end
    
end
   

