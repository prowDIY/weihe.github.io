%% demo NGmeet reconstruction

% clc;
% clear;
addpath('NGmeet')
addpath('NGmeet/Measurements');
addpath('assess_fold')

rates     =    [0.02, 0.05, 0.10, 0.15, 0.2];
idx       =    1;

%% chart_and_stuffed_toy_ms
% load Toy.mat
% ori_im = double(Toy(151:450,171:470,:));
%% WDC
% load x_dc.mat
% ori_im = 255*x_dc/max(x_dc(:));
%% Pavia
load Pavia_80.mat
ori_im=double(OriData3)*255;

[h, w, b] =  size(ori_im);
% ori_im  =  reshape(ori_im, h * w, b);
tic
Rec_im  =  HSImage_CS(ori_im, rates(idx));
NGtime = toc;
Rec_im  =  reshape(Rec_im, h, w, b);
% save Pavia_NGmeet_case2.mat Rec_im NGtime

%save Results_010.mat Rec_im