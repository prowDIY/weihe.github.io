% clc;
% clear;
addpath(genpath([cd,'\']));
addpath('NGmeet/Measurements');
addpath('NGmeet/lib');
addpath('NGmeet/my_toolbox');
addpath('NGmeet')

rates     =    [0.02, 0.05, 0.10, 0.15, 0.2];
idx       =    5;
%% chart_and_stuffed_toy_ms
load Toy.mat
ori_im = double(Toy(151:450,171:470,:));
%% Pavia
% load Pavia_80.mat
% ori_im = 255*OriData3;
%% WDC
% load x_dc.mat
% ori_im = 255*x_dc/max(x_dc(:));

[h, w, b] =  size(ori_im);
% ori_im  =  reshape(ori_im, h * w, b);
Rec_im  =  HSImage_CS(ori_im, rates(idx));
Rec_im  =  reshape(Rec_im, h, w, b);

%save Results_010.mat Rec_im
