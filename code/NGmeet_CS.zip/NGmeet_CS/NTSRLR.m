function [Emsi] = NTSRLR(Nmsi,rate)
%==========================================================================


sizeData        = size(Nmsi);
[par, parBSM]   = ParSet_New(rate); % set parameters and tensor recvery parameters;
Npatch          = Im2Patch3D(Nmsi, par);
sizePatch       = size(Npatch);
Emsi            = Nmsi;
[Sel_arr]       = nonLocal_arr(sizeData, par); % PreCompute the all the patch index in the searching window
L               = length(Sel_arr);

tic
for  iter = 1 : par.Iter
    Curmsi      	= Emsi + par.delta*(Nmsi - Emsi);
    Curpatch        = Im2Patch3D(Curmsi, par); % image to FBPs
    if(iter==1)
        Sigma_arr   = par.SigLam*par.rate * ones(1,L); % First Iteration use the input parameter
    else
        temp        = sum(sum((Curpatch(:,:,Sel_arr)-Npatch(:,:,Sel_arr)).^2,1),2)/prod(sizePatch(1:2));
        Sigma_arr   = par.SigLam*sqrt(abs(par.rate^2*ones(1,L)- temp(:)')); % estimate local noise variance
        parBSM.maxIter = max(parBSM.maxIter-10,15);
    end
    
        %%     block matching to find samilar FBP goups
        unfoldPatch     = Unfold(Curpatch,sizePatch,3)';
        patchXpatch     = sum(unfoldPatch.^2,1);
        index     = zeros(par.patnum,L);
        sizePart  =  250;
        numPart   =  floor(L/sizePart)+1;
        for i = 1:numPart
            tempInd = (i-1)*sizePart+1:min(L,i*sizePart);
            distenMat         = bsxfun(@plus, patchXpatch(Sel_arr(tempInd)), patchXpatch')-2*(unfoldPatch')*unfoldPatch(:,Sel_arr(tempInd));
            [~,tempindex]     = sort(distenMat);
            index(:,tempInd)  = tempindex(1:par.patnum,:);
        end
        clear patchXpatch distenMat unfoldPatch Emsi Curmsi tempInd ;
        Epatch          = zeros(sizePatch);
        W               = zeros(sizePatch(1),sizePatch(3),'single');
        
        sizePart  =  5100;
        numPart   =  floor(L/sizePart)+1;
        for i = 1:numPart
            PattInd = (i-1)*sizePart+1:min(L,i*sizePart);
            tempInd = index(:,PattInd);
            sizeInd = size(tempInd);
            tempPatch = Curpatch(:,:,tempInd(:));
            tempPatch = reshape(tempPatch, [sizePatch(1:2), sizeInd]);
            tempSigma = Sigma_arr(PattInd);
            for j = 1:sizeInd(2)
                tempPatch(:,:,:,j) = NTSRLRReg(tempPatch(:,:,:,j),1/tempSigma(j),parBSM);
            end
            for j = 1:sizeInd(2)
                Epatch(:,:,tempInd(:,j))  = Epatch(:,:,tempInd(:,j)) + tempPatch(:,:,:,j);
                W(:,tempInd(:,j))         = W(:,tempInd(:,j))+ones(size(tempPatch(:,:,:,j),1),size(tempPatch(:,:,:,j),3));
            end
        end
        clear Curpatch;     
 
    clear tempPatch
    time = toc;
    [Emsi, ~]  =  Patch2Im3D( Epatch, W, par, sizeData); % recconstruct the estimated MSI by aggregating all reconstructed FBP goups.
     clear Epatch;
end   
end

function  [SelfIndex_arr]  =  nonLocal_arr(sizeD, par)
% -SelfIndex_arr is the index of keypatches in the total patch index array
TempR         =   sizeD(1)-par.patsize+1;
TempC         =   sizeD(2)-par.patsize+1;
R_GridIdx	  =   1:par.step:TempR;
R_GridIdx	  =   [R_GridIdx R_GridIdx(end)+1:TempR];
C_GridIdx	  =   1:par.step:TempC;
C_GridIdx	  =   [C_GridIdx C_GridIdx(end)+1:TempC];

temp          = 1:TempR*TempC;
temp          = reshape(temp,TempR,TempC);
SelfIndex_arr = temp(R_GridIdx,C_GridIdx);
SelfIndex_arr = SelfIndex_arr(:)';
end

function  [par,parBSM]=ParSet_New(rate)
% parameters setting for ITS_DeNoising

parBSM.lambda     =   10;
parBSM.rho        =   1.2;
parBSM.mu         =   250;
meanD             =   0.2;
DimUpRank         =   [1,1,1];
par.rate          =   0.1;                                 % Variance of the noise image
par.delta         =   0.1;                                  % Parameter between each iter
par.SearchWin     =   80;

if rate <= 0.02
    par.patsize       =   10;                            % Patch size
    par.patnum        =   70;                           % Initial Non-local Patch number
    par.SigLam        =   0.012*meanD*prod(DimUpRank);  % Noise estimete parameter
    parBSM.maxIter    =   25;                           % max iteration number for ITSReg tensor recovery
    par.Iter =   1;                            % total iteration numbers
elseif rate <=0.05
    par.patsize       =   9;                            
    par.patnum        =   65;                           
    par.SigLam        =   0.013*meanD*prod(DimUpRank);
    parBSM.maxIter    =   25;
    par.Iter =   1;
elseif rate <=0.10
    par.patsize       =   8;                            
    par.patnum        =   60;                           
    par.SigLam        =   0.014*meanD*prod(DimUpRank);
    parBSM.maxIter    =   35;
    par.Iter =   1;
elseif rate <=0.15
    par.patsize       =   7;                            
    par.patnum        =   55;                           
    par.SigLam        =   0.015*meanD*prod(DimUpRank);
    parBSM.maxIter    =   35;
    par.Iter =   1;
elseif rate <=0.20
    par.patsize       =   6;                           
    par.patnum        =   50;                          
    par.SigLam        =   0.016*meanD*prod(DimUpRank);
    parBSM.maxIter    =   30;
    par.Iter =   1;
end
par.step          =   floor((par.patsize-1)); 
parBSM.maxIter    =   parBSM.maxIter-2;
end


