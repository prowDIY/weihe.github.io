source /opt/intel/bin/iccvars.sh intel64
