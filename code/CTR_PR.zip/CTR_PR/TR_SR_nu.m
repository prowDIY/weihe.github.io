function [HR_HSI] = TR_SR_nu(HSI,MSI,T,BW,BH,downsampling_scale,par,s0,S)
%addpath('TR','TR/TR_functions','TR/TensorRing','TR/TR_Toolbox_SGD','TR/TR_Toolbox_SGD/corefun/')
mu = 0.001;
Rank = par.r;
tao = 0.001;
K_max=10^6;
ro = 1.5;
K = 1e-2;
%%  simulate LR-HSI
Y_h_bar=hyperConvert2D(HSI);
HSI1=tenmat_sb(HSI,1);
HSI2=tenmat_sb(HSI,2);
HSI3=tenmat_sb(HSI,3);
%%  simulate HR-MSI
MSI1=tenmat_sb(MSI,1);
MSI2=tenmat_sb(MSI,2);
MSI3=tenmat_sb(MSI,3);
%% inilization D1 D2 D3
core=tensor_ring1(MSI,'Tol',1e-3,'Alg','ALS','Rank',Rank);  %
G = core.node;
D1 = G{1}; D2 = G{2}; %D_3 = G{3};
D_1=ifft(fft(Gunfold(D1,2)).*repmat(BW,[1 Rank(1)*Rank(2)]));
D_1=Gfold(D_1(s0:downsampling_scale:end,:),[Rank(1),size(HSI,1),Rank(2)],2);

D_2=ifft(fft(Gunfold(D2,2)).*repmat(BH,[1 Rank(2)*Rank(3)]));
D_2=Gfold(D_2(s0:downsampling_scale:end,:),[Rank(2),size(HSI,2),Rank(3)],2);

% core=tensor_ring1(HSI,'Tol',1e-2,'Alg','ALS','Rank',Rank);
% G = core.node;
% % D_1 = G{1}; D_2 = G{2}; 
% D3 = G{3}; %D_3=T*D3;
% D_3=Gfold(T*(Gunfold(D3,2)),[Rank(3),size(MSI,3),Rank(1)],2);
% params.Tdata = 2;            % Number of target sparse vectors
% params.dictsize =Rank(1)*Rank(2);      %   441;      % Number of dictionary elements (# columns of D)
% params.iternum = 100;
% params.DUC =1; 
% D1 = trainD(MSI1,MSI1,[],[],params);
% params.dictsize =Rank(2)*Rank(3);
% D2 = trainD(MSI2,MSI2,[],[],params);
% 
% D_1=ifft(fft(D1).*repmat(BW,[1 Rank(1)*Rank(2)]));
% D1 =  Gfold(D1,[Rank(1),size(MSI,1),Rank(2)],2); 
% D_1=Gfold(D_1(s0:downsampling_scale:end,:),[Rank(1),size(HSI,1),Rank(2)],2);
% 
% D_2=ifft(fft(D2).*repmat(BH,[1 Rank(2)*Rank(3)]));
% D2 =  Gfold(D2,[Rank(2),size(MSI,2),Rank(3)],2); 
% D_2=Gfold(D_2(s0:downsampling_scale:end,:),[Rank(2),size(HSI,2),Rank(3)],2);


D3=vca(Y_h_bar,Rank(3)*Rank(1));
D_3=Gfold(T*D3,[Rank(3),size(MSI,3),Rank(1)],2);
D3 =  Gfold(D3,[Rank(3),size(HSI,3),Rank(1)],2); 

D11{1}=D_1;
D11{2}=D_2;
D11{3}=D3;
D22{1}=D1;
D22{2}=D2;
D22{3}=D_3;
%% variable
Y = zeros(size(Gunfold(D3,2)));
M = (Gunfold(D3,2));
%% iteration
for i=1:30
%  update D1
QH=tenmat_sb(Z_neq(D11',1),2);  QH=QH';
QM=tenmat_sb(Z_neq(D22',1),2);  QM=QM';
D1_M = Gunfold(D1,2);
[ D1 ] = DIC_CG1( MSI1, D1_M, QM,HSI1,downsampling_scale,s0,BW,QH,mu);
D_1=ifft(fft(D1).*repmat(BW,[1 Rank(1)*Rank(2)]));
D1 =  Gfold(D1,[Rank(1),size(MSI,1),Rank(2)],2); 
D_1=Gfold(D_1(s0:downsampling_scale:end,:),[Rank(1),size(HSI,1),Rank(2)],2);

D11{1} = D_1;D22{1} = D1;
%%  update D2
QH=tenmat_sb(Z_neq(D11',2),2);  QH=QH';
QM=tenmat_sb(Z_neq(D22',2),2);  QM=QM';
D2_M = Gunfold(D2,2);
[ D2 ] = DIC_CG1( MSI2, D2_M, QM,HSI2,downsampling_scale,s0,BH,QH,mu );
D_2=ifft(fft(D2).*repmat(BH,[1 Rank(2)*Rank(3)]));
D2 =  Gfold(D2,[Rank(2),size(MSI,2),Rank(3)],2); 
D_2=Gfold(D_2(s0:downsampling_scale:end,:),[Rank(2),size(HSI,2),Rank(3)],2);

D11{2} = D_2;D22{2} = D2;
%%  update D3
QH=tenmat_sb(Z_neq(D11',3),2);  QH=QH';
QM=tenmat_sb(Z_neq(D22',3),2);  QM=QM';
D3_M = Gunfold(D3,2);
D3_M = (2*mu*D3_M+K*M+Y)/(2*mu+K);
% D3_M = (K*M-Y)/(K);
[ D3 ] = DIC_CG( HSI3, D3_M, QH,MSI3,T,QM,mu+K/2);%
D_3=Gfold(T*D3,[Rank(3),size(MSI,3),Rank(1)],2);
D3 =  Gfold(D3,[Rank(3),size(HSI,3),Rank(1)],2); 

D11{3} = D3;D22{3} = D_3;

%% update K M
D3_M = Gunfold(D3,2)-Y/K;
M=Pro2TraceNorm(D3_M,tao/K);

Y=Y+K*(M-Gunfold(D3,2));
K=min(K*ro,K_max);
 %%  reconstruct
 GG=[];GG{1} = D1;GG{2} = D2;GG{3} = D3;
 HR_HSI=coreten2tr(GG);
 HR_HSI=double(HR_HSI);

%rmse1=getrmse(double(im2uint8(S)),double(im2uint8(HR_HSI)))
rmse1=getrmse(double(S*255),double(HR_HSI*255));
end
end

