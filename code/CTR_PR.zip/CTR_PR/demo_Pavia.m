clear
clc
addpath(genpath('TRD_function'))
addpath(genpath('metric'))
%% load HR-HSI
load Pavia
S = double(S);
S = S/max(S(:));
Scale = 8;
SNR = 40;
%%  simulate HSI
[M,N,L] = size(S);
S_bar = hyperConvert2D(S);
downsampling_scale = Scale;
s0 = downsampling_scale/2;
BW = ones(9,1)/9;
BW1 = psf2otf(BW,[M 1]);
S_w = ifft(fft(S).*repmat(BW1,1,N,L)); %blur with the width  mode
 
BH = ones(9,1)/9;
BH1 = psf2otf(BH,[N 1]);
aa = fft(permute(S_w,[2 1 3]));
S_h = (aa.*repmat(BH1,1,M,L));
S_h = permute(ifft(S_h),[2 1 3]);  %blur with the height mode
Y_h = S_h(s0:downsampling_scale:end,s0:downsampling_scale:end,:);% uniform downsamping
Y_h_bar = hyperConvert2D(Y_h);
%%%%%%%%% HSI add noise %%%%%%%%%%%%%
SNRh = SNR;
sigmam = sqrt(sum(Y_h_bar(:).^2)/(10^(SNRh/10))/numel(Y_h_bar));
rng(1)
Y_h_bar = Y_h_bar + sigmam*randn(size(Y_h_bar));
HSI = hyperConvert3D(Y_h_bar, M/downsampling_scale, N/downsampling_scale );
%%  simulate MSI
Y = F*S_bar;
%%%%%%%%% MSI add noise %%%%%%%%%%%%%
SNRm = SNR;
sigmam = sqrt(sum(Y(:).^2)/(10^(SNRm/10))/numel(Y));
Y = Y+ sigmam*randn(size(Y));
MSI = hyperConvert3D(Y, M, N);

par.r = [4,150,4]; 
CTR_HSR = TR_SR(HSI,MSI,F,BW1,BH1,downsampling_scale,par,s0,S);
[psnr4, rmse4, ergas4, sam4, uiqi4, ssim4, DD4, CC4] = quality_assessment(CTR_HSR*255, S*255, 0, 1.0/downsampling_scale);

