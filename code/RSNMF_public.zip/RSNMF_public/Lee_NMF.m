function [W H obj it]=Lee_NMF(V,r,opts)
defopts=struct('maxiter',1000,'tol',1e-6,'trackit',20,'w',[],'h',[],'Vtrue',[]);
if ~exist('opts','var')
    opts=struct;
end
[MaxIt, tol, trackit,W,H,Vtrue]=scanparam(defopts,opts);
if isempty(Vtrue)
    Vtrue=V;
end
ts=clock;
eps=1e-9;

[M L]=size(V);
V=max(V,0);

    
%% Initialization;
if isempty(W)
    W=rand(M,r);
end
if isempty(H)
    H=rand(r,L);
end

%%%%%%%%%%%%sum to 1 or not
delta = 6e1; V0 = [V;delta*ones(1,L)];
%%%%%%%%%%%
% I=eye(r,r);
obj=inf;
objH=inf;
for it=1:MaxIt
    
    W0=W;
    H0 =H;
    W=W.*((V*H')./max(W*H*H',eps));
  
    WE = [W;delta*ones(1,r)];
    H=H.*((WE'*V0)./max((WE'*WE)*H,eps));
    
%     H=H.*((W'*V)./max((W'*W)*H,eps));
    
%     W=max(W,eps);
%     
%     sumW=max(sum(W),eps);
%     H=bsxfun(@times,H,sumW');
%     W=bsxfun(@rdivide,W,sumW);
    
 
obj(it)=norm(W-W0,'fro');   
    if (trackit>0)&&(~rem(it,trackit))&&(it>MaxIt*0.2)  %mean trackit >0, it���������������Ҵ���0.2 
        if obj(it)<tol
            break;
        end
    end
%     if (trackit>0)&&(~rem(it,trackit))&&(it>MaxIt*0.2)  %mean trackit >0, it���������������Ҵ���0.2 
%         if norm(W-W0,'fro')<tol && norm(H-H0,'fro')<tol
%             break;
%         end
%     end
%     obj(it)=norm(Vtrue-W*H,'fro');
% obj(it)=norm(W-W0,'fro');
% objH(it)=norm(H-H0,'fro');
end

t=etime(clock,ts);
