%% simulated in the case of MVCNMF
% clc;close all;
% clear all;

% read data
% addpath 'simulated data'
 load signatures
ratio = 0.2; % S&P������ǿ��
pencent = 0.2;% ��S&PӰ�첨����ռ�ı���
SNR = 30; %dB % Gaussian������ǿ��
c = 4;        % ��Ԫ����
% A = A(:,[1; 5; 7;  12; 21]); 
A = A(:,[1; 5; 7; 21]); 
% [mixed, abf] = getSynData(A, 7, 0);
load simu1
[M,N,D] = size(mixed);
% clear mixed;
% load noise_image
mixed = reshape(mixed,M*N,D);
ss=mixed;
% mixed = mixed';
% add Gaussian noise
variance = sum(mixed(:).^2)/10^(SNR/10)/M/N/D;
n = sqrt(variance)*randn([D M*N]);
mixed = mixed' + n;
sss = mixed;
% add S%P noise
Idx = randperm(D);SPnum = round(D*pencent);
for i =1:SPnum
    vv = Idx(i);
     mixed(vv,:)=imnoise(mixed(vv,:),'salt & pepper',ratio);
end
%% NMF RNMF
% parameters
% gamma = 1; % only for L_1/2 RNMF
sparse_type = 0;  % choose 0 for L_1/2 sparsity pattern
                  % choose 1 for L_1 sparsity pattern
opt_mult = struct('maxiter',1000,'tol',1e-4,'trackit',20,'w',[],'h',[],'Vtrue',[]);
% [Aest sest obj it]=Lee_SNMF(mixed,c,opt_mult,sparse_type);
[Aest sest obj S]=Lee_RNMF_sparse(mixed,c,opt_mult,2,sparse_type);
% [Aest sest obj it]=Lee_NMF(mixed,c,opt_mult);
% [Aest sest obj it S]=Lee_RNMF(mixed,c,opt_mult);
%%      
% permute results
CRD = corrcoef([A Aest]);
DD = abs(CRD(c+1:2*c,1:c));  
perm_mtx = zeros(c,c);
aux=zeros(c,1);
for i=1:c
    [ld cd]=find(max(DD(:))==DD); 
    ld=ld(1);cd=cd(1); % in the case of more than one maximum
    perm_mtx(ld,cd)=1; 
    DD(:,cd)=aux; DD(ld,:)=aux';
end
Aest = Aest*perm_mtx;
sest = sest'*perm_mtx;
Sest = reshape(sest,[M,N,c]);
sest = sest';

% show the estimations
E_rmse =zeros(1,c);
for i=1:c
    E_rmse(i)=sqrt(sum((abf(i,:)-sest(i,:)).^2)/(M*N));
end
RMSE = mean(E_rmse)
 SADerr = zeros(c,c);
for i =1:c
    for j = 1:c
    SADerr(i,j) = acos(A(:,j)'*Aest(:,i)/norm(A(:,j))/norm(Aest(:,i)));
    end
end
SAD = mean(diag(SADerr))
