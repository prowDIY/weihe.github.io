function [W H obj S]=Lee_RNMF_sparse(V,r,opts,gamma, sparse_type)
defopts=struct('maxiter',1000,'tol',1e-6,'trackit',20,'w',[],'h',[],'Vtrue',[]);
if ~exist('opts','var')
    opts=struct;
end
[MaxIt, tol, trackit,W,H,Vtrue]=scanparam(defopts,opts);
if isempty(Vtrue)
    Vtrue=V;
end
ts=clock;
eps=1e-9;
[M L]=size(V);
V=max(V,0);
  
%% Initialization;
if isempty(W)
    rand('seed',70)
    W=rand(M,r);
end
if isempty(H)
    rand('seed',20)
    H=rand(r,L);
end
AS = sum(H);
H = H./repmat(AS,size(H,1),1);

%%%%%%%%%%����ÿ��������������ֵ��ͳһ�����gammaֵ������ɢ������
% gamma =1.5;
% card = round(0.2*M*L);  
% Weight = ones(1,size(V,1));%Weight = max(V,[],2);
% gamma_W = gamma*Weight;
gamma_W = gamma;
% gamma = repmat(gamma_W,1,L);
%%%%%%%%%%%% sparsity level
attend = zeros(1,M);
for i = 1:M
    attend(i)= (sqrt(L)- norm(V(i,:),1)/norm(V(i,:),2))/(sqrt(L-1));
end
lambda = sum(attend)/sqrt(M)/10;

%%%%%%%%%%%%sum to 1 or not
delta = 1.5e1; %V0 = [V;delta*ones(1,L)];
%%%%%%%%%%% Sparse constraint
S = zeros(M,L);
% I=eye(r,r);
obj=inf;
objH = inf;

%% choose sparse_type 0 for L_1/2; and 1 for L1

if sparse_type==0  % For L_1/2 RNMF
  
for it=1:MaxIt
    W0=W;
    W=W.*(max((V-S)*H',0)./max(W*H*H',eps));
  
    WE = [W;delta*ones(1,r)];
    Vo = [V-S;delta*ones(1,L)];
%     WE = W;
%     Vo = V-S;
    idx = find(H<=1e-4); PG = (max(H,eps)).^(-0.5); PG(idx) = 1e-4;
    H=H.*((WE'*Vo)./max((WE'*WE)*H + 0.5*lambda*PG,eps)); %L1/2 Sparse
    
%    Update of S    
    % solve S via L_21 norm
    temp_T = V - W*H;
    S = solve_l1l2(temp_T,gamma_W);
     
    if (trackit>0)&&(~rem(it,trackit))&&(it>MaxIt*0.2)  %mean trackit >0, it���������������Ҵ���0.2 
        obj(it)=norm(W-W0,'fro');
        if obj(it)<tol 
            break;
        end
    end

end

elseif sparse_type ==1  % For L_1 RNMF
  
for it=1:MaxIt
    W0=W;
    W=W.*(max((V-S)*H',0)./max(W*H*H',eps));
  
    WE = [W;delta*ones(1,r)];
    Vo = [V-S;delta*ones(1,L)];

    H=H.*((WE'*Vo)./max((WE'*WE)*H + lambda,eps));% L1 spars��    
%     % solve S via L_21 norm
    temp_T = V - W*H;
    S = solve_l1l2(temp_T,gamma_W);
     
    if (trackit>0)&&(~rem(it,trackit))&&(it>MaxIt*0.2)  %mean trackit >0, it���������������Ҵ���0.2 
        obj(it)=norm(W-W0,'fro');
        if obj(it)<tol 
            break;
        end
    end

end
end

function [E] = solve_l1l2(Temp_T,gamma)
n = size(Temp_T,1);
E = Temp_T;
for i=1:n
    E(i,:) = solve_l2(Temp_T(i,:),gamma);
end

% function [E] = solve_l1l2(Temp_T,gamma)  %% for column sparsity
% n = size(Temp_T,2);
% E = Temp_T;
% for i=1:n
%     E(:,i) = solve_l2(Temp_T(:,i),gamma);
% end

function [x] = solve_l2(temp_r,gamma)
% min lambda |x|_2 + |x-w|_2^2
temp = norm(temp_r);
if temp>gamma
    x = (temp-gamma)*temp_r/temp;
else
    x = zeros(1,length(temp_r));
end
