% This package contains a matlab implementation of the RNMF algorithm [1].
%
% Pleae run the "Demo_simu_SRNMF.m" file
%
%[1]He W., Zhang H., Zhang L. 2016. Sparsity-Regularized Robust Non-Negative
% Matrix Factorization for Hyperspectral Unmixing [J]. IEEE Journal of 
% Selected Topics in Applied Earth Observations and Remote Sensing, 9(9): 4267-4279.

% Author: Wei He (November, 2015)
% E-mail addresses:(weihe1990@whu.edu.cn)
