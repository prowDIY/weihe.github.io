function [W H obj it]=Lee_SNMF(V,r,opts, sparse_type)

% for L1/2 sparse�� ref lambda /5 and ref delta = 5; 
defopts=struct('maxiter',1000,'tol',1e-6,'trackit',20,'w',[],'h',[]);
if ~exist('opts','var')
    opts=struct;
end
[MaxIt, tol, trackit,W,H]=scanparam(defopts,opts);

eps=1e-9;

[M L]=size(V);
V=max(V,0);

  
%% Initialization;
if isempty(W)
%     rand('seed',100)
    rand('seed',2413)
    W=rand(M,r);
end
if isempty(H)
%     rand('seed',156)
      rand('seed',67)
    H=rand(r,L);
    AS = sum(H);
    H = H./repmat(AS,size(H,1),1);
end


%%%%%%%%%%%% sparsity
attend = zeros(1,M);
for i = 1:M
    attend(i)= (sqrt(L)- norm(V(i,:),1)/norm(V(i,:),2))/(sqrt(L-1));
end
% lambda = sum(attend)/sqrt(M);
lambda = sum(attend)/sqrt(M)/1;


% operatorA=@(W,H,V) norm(V-W*H,'fro')/2+ lambda*sum(sum(sqrt(H))); 
%%%%%%%%%%%%sum to 1 or not
delta = 1.5e1; Vo = [V;delta*ones(1,L)];
%%%%%%%%%%%
% I=eye(r,r);
obj=inf;

%% choose sparse_type 0 for L_1/2; and 1 for L1

if sparse_type==0  % For L_1/2 NMF
    
for it=1:MaxIt
    W0=W;
    W=W.*((V*H')./max(W*H*H',eps));
  
    WE = [W;delta*ones(1,r)];
    idx = find(H<=1e-4); PG = (max(H,eps)).^(-0.5); PG(idx) = 1e-4;
    H=H.*((WE'*Vo)./max((WE'*WE)*H + 0.5*lambda*PG,eps)); %L1/2 Sparse
%     H=H.*((WE'*Vo)./max((WE'*WE)*H + lambda,eps));% L1 sparse
    if (trackit>0)&&(~rem(it,trackit))&&(it>MaxIt*0.2)  %mean trackit >0, it���������������Ҵ���0.2 
        obj(it)=norm(W-W0,'fro');  
        if obj(it)<tol
            break;
        end    
    end
end

elseif sparse_type ==1  % For L_1 NMF
    
for it=1:MaxIt
    W0=W;
    W=W.*((V*H')./max(W*H*H',eps));
  
    WE = [W;delta*ones(1,r)];
    idx = find(H<=1e-4); PG = (max(H,eps)).^(-0.5); PG(idx) = 1e-4;
    H=H.*((WE'*Vo)./max((WE'*WE)*H + lambda,eps));% L1 sparse
    

    if (trackit>0)&&(~rem(it,trackit))&&(it>MaxIt*0.2)  %mean trackit >0, it���������������Ҵ���0.2 
        obj(it)=norm(W-W0,'fro');  
        if obj(it)<tol
            break;
        end    
    end
end
    
end  

