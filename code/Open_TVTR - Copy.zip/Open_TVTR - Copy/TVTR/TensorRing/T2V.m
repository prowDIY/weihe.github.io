function v= T2V(T)
    % vectorize a tensor
    v = T(:);
end