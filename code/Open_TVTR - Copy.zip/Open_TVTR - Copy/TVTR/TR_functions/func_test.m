%% tenmat2tensor test

X=rand(3,4,5,6,7,8);
S=size(X);
N=numel(S);
X1=double(tenmat(X,1));
X2=double(tenmat(X,2));
X6=double(tenmat(X,6));

X1_=tenmat2tensor(X1,S,1);
isequal(X,X1_)

X2_=tenmat2tensor(X2,S,2);
isequal(X,X2_)

X6_=tenmat2tensor(X6,S,6);
isequal(X,X6_)

%% mode2core2tensor test
S=[3,4,5,6,7,8];
N=numel(S);
r=12*ones(N-1,1);
G=initcoreten(S,r);
Gm=G;
G_=G;
for i=1:N
    Gm{i}=double(tenmat(G{i},2));
    G_{i}=mode2core2tensor(Gm{i},r,S,i);
end
isequal(G,G_)

%% Msum_fun test
X=rand(3,4,5,6,7,8);
S=size(X);N=numel(S);
G=TR_initcoreten(S,10*ones(6,1));
M=cell(N,3); 
for i=1:N
    G{i}=ones(size(G{i}));
    for j=1:3
        M{i,j}=ones(size(G{i}));
    end
end
Msum=Msum_fun(M);

%% Gunfold Gfold test
X=rand(3,4,5);
S=size(X);
i=3;
X2=Gunfold(X,i);
X2_=double(tenmat(X,i));
%isequal(X2,X2_)

X_=Gfold(X2,S,i);
isequal(X,X_)

%% mytenmat test
X=rand(3,4,5,6,7,8);
S=size(X);N=numel(S);
X1=mytenmat(X,1);X1_=double(tenmat(X,1));
X2=mytenmat(X,2);X2_=double(tenmat(X,2));
X6=mytenmat(X,6);X6_=double(tenmat(X,6));

isequal(X1,X1_)
isequal(X2,X2_)
isequal(X6,X6_)