load HSI.mat
G=cell(11,1);
for i=1:11
    G{i}=imresize(HSI(:,:,3*i-2:3*i),[64,64]);
end
X___=G{1};
for i=1:10
    X___=cat(3,X___,G{i+1});
end