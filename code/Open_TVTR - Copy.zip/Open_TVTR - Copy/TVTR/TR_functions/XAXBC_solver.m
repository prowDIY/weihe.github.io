% solver of X-AXB=C
function X_out=XAXBC_solver(A,B,C)
Sx=size(C);
KronAB=kron(A,B');
VecX=pinv(eye(size(KronAB))- KronAB)*C(:);
X_out=reshape(VecX,Sx);
end