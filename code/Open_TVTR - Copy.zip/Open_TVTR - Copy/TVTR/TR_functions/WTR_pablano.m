function X_hat=WTR_pablano(X,W,para)

Z0_v=TR_initcoreten(size(X),para.r);
Z0_v=0.08*Zm2Zv(Zt2Zm(Z0_v));
fprintf('------TR Weighted Optimization ---------- \n\n');
 options = lbfgs('defaults');
 options.MaxIters =para.maxiter;
 options.StopTol = para.tol;
 options.RelFuncTol = 1.0e-100;
 options.DisplayIters = 50;
 options.MaxFuncEvals=1.0e+100;
 out=lbfgs(@(Zv) tr_wfg(X,W,Zv,para.r),Z0_v, options);
 Z_opted=Zm2Zt(Zv2Zm(out.X,size(X),para.r),para.r);
 X_hat=coreten2tr(Z_opted);
end