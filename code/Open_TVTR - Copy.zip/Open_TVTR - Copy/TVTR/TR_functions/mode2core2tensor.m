function Gt=mode2core2tensor(G,r,S,n)

        N=numel(S);
        if n==1
            Gt=reshape(G,[S(n),1,r(n)]);
            Gt=permute(Gt,[2,1,3]);
        elseif n==N
            Gt=reshape(G,[S(n),r(n-1),1]);
            Gt=permute(Gt,[2,1]);
        else
            Gt=reshape(G,[S(n),r(n-1),r(n)]);
            Gt=permute(Gt,[2,1,3]);
        end

end