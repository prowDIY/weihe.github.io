% sum square root calculator
function SSR_out=SSR_fun(r)
SSR_out=sum(sqrt(r));
end