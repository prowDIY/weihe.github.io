%% TT_BALS test
S=[7,8,9,10,6];
r=[5,7,3,5];
G=initcoreten(S,r);
X=10*coreten2tt(G);
r_init=[10,10,10,10];
[G_opted, r_opted]=TT_BALS(X,r_init,10,1e-4);
fprintf('real tt-rank:'); disp(r);
fprintf('initial tt-rank:'); disp(r_init);
fprintf('optimized tt-rank:'); disp(r_opted');

%% TT_G_init test
S=[7,8,9,10,6];
X=rand(S);W=ones(S);
r=2*[10,10,10,10];

[G_init,r_init]=TT_G_init(X,W,r);

%% TR_Z_init test
S=[7,8,9,10,6];
X=rand(S);W=ones(S);
r=2*[10,10,10,10];

[Z_init,r_init]=TR_Z_init(X,W,r);

%% TR_ALS
image=imread('2_lena.bmp');
image=imresize(image,[256 256]);
X = double(image)/255;
%X=reshape(X,16,16,16,16,3);
S=size(X);N=numel(S);

mr=0.9;
W=gen_W(S,mr);

para_TR.disp =10;
para_TR.r = 60*ones(1,N); % Tensor Ring Rank
para_TR.max_tot=1e-6;
para_TR.max_iter=200;

X_hat_a = coreten2tr(TR_ALS(X, W, para_TR));
X_hat_a(W==1)=X(W==1);

RSE=RSE_fun(X,X_hat_a,W)

%% TT_SiLRTC test 
image=imread('2_lena.bmp');
image=imresize(image,[256 256]);
X = double(image)/255;
%X=reshape(X,4,4,4,4,4,4,4,4,3);
S=size(X);N=numel(S);

mr=0.5;
W=gen_W(S,mr);

alpha=ones(1,N);
beta = 5e0*ones(1, N);
maxIter=200;
epsilon = -1e-8;
[X_hat, errList] = SiLRTC(X, (W==1), ones(1,N), 5e0*ones(1, N), maxIter, epsilon);

RSE=RSE_fun(X,X_hat,W)

%% BCPF_TC
S=[20,20,20,20];
%S=[4,5,4,5,4,5,4,5];
N=numel(S);
r=5*ones(1,N);
r_init=6*ones(1,N);
G=TR_randcoreten(S,r);
SSR_real=SSR_fun(r);
SSR=SSR_fun(r_init);
X=coreten2tr(G);
mr=0.7;
W=gen_W(S,mr);
maxIter=200;
[model] = BCPF_TC(X, 'obs', W, 'init', 'ml', 'maxRank', 2*r_init(1), 'dimRed', 1, 'tol', 1e-6, 'maxiters', 100, 'verbose', 1);
X_hat=double(model.X);
X_hat(W==1)=X(W==1);
RSE=RSE_fun(X,X_hat,W)

%% HaLRTC
image=imread('2_lena.bmp');
image=imresize(image,[256 256]);
X = double(image)/255;
%X=reshape(X,16,16,16,16,3);
S=size(X);N=numel(S);

mr=0.9;
W=gen_W(S,mr);

[X_hat, ~] = HaLRTC(X,W==1, ones(1,N)/N, 1e-3, 200, 0);
RSE=RSE_fun(X,X_hat,W)