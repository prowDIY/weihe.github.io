% tensor-ring overlapped low-rank factor

function [X,G_out,Convergence_rec]=TRLRF_CTV(data,W,r,maxiter,K,ro,Lamda,tol)
addpath('TVTR\TensorRing')
% T = data;
% X = T;
T=data.*W;
N=ndims(T);
S=size(T);
% X = T;
% X=zeros(S);
% X(W==0)=mean(T(:));
% X(W==1)=T(W==1);
X=rand(S);
% X = init_X(T,W,S);
%%
% G = TR_Initialization(X,  r);
G=TR_initcoreten(S,r);
M=cell(N,1); 
Y=cell(N,1);
for i=1:N
    G{i}=1*G{i};
    M{i}=zeros(size(G{i}));
    Y{i}=sign(G{i});
end

%% for TV regularization
% for the TV norm
param2.verbose=1;
param2.max_iter=100;
param2.verbose = 0;
tau = 0.0015;

%%
%K=1e-6;
%ro=1.01;
K_max=10^2;
%Lamda=1;
Convergence_rec=zeros(1,maxiter);
iter=0;
while iter<maxiter
    iter=iter+1;
        % update G
    for n=1:N
%         Msum=Msum_fun(M);
%         Ysum=Msum_fun(Y);
        Q=tenmat_sb(Z_neq(G,n),2);  Q=Q'; % Q is the right part of the right part of the relation equation
%         G{n}=Gfold(tenmat_sb(X,n)*Q'*pinv(Q*Q'+3*K*eye(size(Q,1),size(Q,1))),size(G{n}),2);
        G{n}=Gfold((Lamda*tenmat_sb(X,n)*Q'...
            +K*Gunfold(M{n},2)+Gunfold(Y{n},2))*pinv((Lamda*(Q*Q')...
            +K*eye(size(Q,1),size(Q,1)))),size(G{n}),2);
        % update M
%         for j=1:3
            M{n}=G{n} - Y{n}/K;
%             M{n,j}=Gfold(Pro2TraceNorm(Df,1e0/K),size(G{n}),j);
%         end
        
    end
    % update X
    lastX=X;
    X_u=coreten2tr(G);
    X=X_u;
%     Xw=X.*W;
%     X(W==1)=T(W==1);
    
    for i =1:S(3)  
      z = prox_TV(X_u(:,:,i),tau/(2*Lamda),param2);
      X(:,:,i) = z;  
    end
    Xw=X.*W;
    X(W==1)=T(W==1);
%%       
    % update Y
    for n=1:N
        Y{n}=Y{n}+K*(M{n}-G{n});
    end
    K=min(K*ro,K_max);
    
    % evaluation
    G_out=G;

    err_x=abs((norm(lastX(:))-norm(X(:)))/norm(T(:)));
    if (err_x<tol)
    %    fprintf('iteration stop at %.0f\n',iter); break
    end
     
%    RSE=RSE_fun(data,X_u,W);
% [PSNR,~,~,~] = evaluate(data,X,size(X,1),size(X,2));
% ABC = mean(PSNR);ABC1 =ABC;
ABC = 0;ABC1 =0;
%    ABC=PSNR(255*data(:,:,19),255*X_u(:,:,19),S(1),S(2));
%    ABC1=PSNR(255*data(:,:,19),255*X(:,:,19),S(1),S(2));
 %   if (mod(iter,30)==0 || iter ==1)
    if (mod(iter,1)==0 || iter ==1)
        Ssum_G=0; % singular value
%         Ssum_M=0; % singular value
        for j=1:N
            [~,vz,~]=svd(double(tenmat(G{j},1)),0);
            Ssum_G=Ssum_G+sum(vz(:));
%             [~,vm,~]=svd(double(tenmat(Msum{j},1)),0);
%             Ssum_M=Ssum_M+1/3*sum(vm(:));
        end
        
        f_left=Ssum_G;
        f_right=Lamda*(norm(T(:)-Xw(:)))^2;
%         Convergence_rec(iter)=f_left+f_right;
%          Convergence_rec(iter) = ABC;
        fprintf('TRLRF: Iteration %.0f, RSEw %.3d, f_left %.3f, f_right %.3f\n',iter,ABC,ABC1,f_right);
    end
    
end
end