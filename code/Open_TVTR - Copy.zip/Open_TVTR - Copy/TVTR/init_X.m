function X=init_X(T,W,S)

%% initilization of X
spe = 4; % for RGB
% spe = 4;(6)
tim = S(3)/spe;
X_init = reshape(T,S(1),S(2),spe,tim);
W_data = reshape(W,S(1),S(2),spe,tim);
for row =1:S(1)
    for col=1:S(2)
        for band = 1:spe
            point = W_data(row,col,band,:); point = point(:);
            idx = find(point==0);idx1 = find(point>0);
            if length(idx)>0
                if length(idx1)>0
                X_init(row,col,band,idx) = sum(X_init(row,col,band,idx1))/length(idx1);
                else
                X_init(row,col,band,idx) =0;
                end
            end
        end
    end
end
X = reshape(X_init,S(1),S(2),S(3));
end