% demo completion
% clc;clear all
addpath('TVTR/functions')
%% image load; include input noisy image X and mask image W
% % HSI
load WDC.mat
In_X=WDC(:,:,5:34);
% In_X=WDC(:,:,5:34);
X =In_X;
sz = size(X);
S=size(In_X);N=ndims(In_X);
mr=0.9;              % Missing rate: [0 ~ 1]
W=gen_W(S,mr);
W =logical(W);
In_X=In_X.*W;
% % when the missing percentage is 90, Lamda =1; K = 1e-6; and rinit=
% [15,15,5] [20 20 10] [20 20 15]. Lambda=10 for 5 and 1
%
% load HSI_5.mat
%% method selection
Comparison_LRSD = 0;
Comparison_TMac = 0;
Comparison_HaLRTC=0;
Comparison_tSVD = 0;
Comparison_LRTCTV = 0;
Comparison_TTSGD = 0;
Comparison_TRALS = 0;
Comparison_TVLRC =1;
%%
if Comparison_LRSD == 1;
%     addpath code_LRRSDS
    lambda = 1; % parameter for low rank regularization
%     lambda_s = 0.05; % parameter for sparse regularization
    Desired_rank = 4;
    AL_iter = 500;
    tic
[output_image] = LRSD(In_X.*W,W,lambda,Desired_rank,AL_iter);
output_image(W==1)=X(W==1);
% [output_image,~]=WH_LRMC(In_X.*W,W,300);
LRSD_time = toc;
[LRSD_PSNR,LRSD_SSIM,LRSD_SAM,LRSD_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:LRSD       ', ', MPSNR=' num2str(mean(LRSD_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(LRSD_SSIM),'%5.4f')  ',SAM=' num2str(LRSD_SAM,'%5.2f')...
           ',MQ=' num2str(mean(LRSD_MQ),'%5.4f') ',Time=' num2str(mean(LRSD_time),'%5.2f')]);
% save HSI_LRSD.mat output_image LRSD_PSNR LRSD_SSIM LRSD_SAM LRSD_time
% LRSD_denoise = output_image;
end
%% TMac
% Xu, Yangyang, et al. "Parallel matrix factorization for low-rank
% tensor completion." arXiv preprint arXiv:1312.1254 (2013).

if Comparison_TMac == 1
addpath('Completionall/TMac')
    params.T=In_X.*double(W);
    params.Idx=double(W);
tic
output_image = run_tc_tmac(params);
output_image(W==1)=X(W==1);
TMac_time=toc;
[TMac_PSNR,TMac_SSIM,TMac_SAM,TMac_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TMac       ', ', MPSNR=' num2str(mean(TMac_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TMac_SSIM),'%5.4f')  ',SAM=' num2str(TMac_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TMac_MQ),'%5.4f') ',Time=' num2str(mean(TMac_time),'%5.2f')]);
rmpath('Completionall/TMac')
% save HSI_TMac.mat output_image TMac_PSNR TMac_SSIM TMac_SAM TMac_time
end

%% HaLRTC
% Liu, Ji, et al. "Tensor completion for estimating missing values in visual data."
% IEEE transactions on pattern analysis and machine intelligence 35.1 (2013): 208-220.
if Comparison_HaLRTC == 1
addpath('Completionall/SiLRTC_FaLRTC_HaLRTC')
addpath('Completionall/SiLRTC_FaLRTC_HaLRTC/mylib')
N=ndims(X);
alpha=[1,1,20];
beta = 1e-6;
maxIter=500;
epsilon = 0;
Omega=(W==1);
mu = 1 * alpha ./ sqrt(size(X));
C =  0.6;
L0 = 1e-6;
tic
[output_image, errList] = HaLRTC(In_X,Omega, alpha, beta, maxIter, epsilon);
HaLRTC_time=toc;
[HaLRTC_PSNR,HaLRTC_SSIM,HaLRTC_SAM,HaLRTC_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:HaLRTC       ', ', MPSNR=' num2str(mean(HaLRTC_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(HaLRTC_SSIM),'%5.4f')  ',SAM=' num2str(HaLRTC_SAM,'%5.2f')...
           ',MQ=' num2str(mean(HaLRTC_MQ),'%5.4f') ',Time=' num2str(mean(HaLRTC_time),'%5.2f')]);
 rmpath('Completionall/SiLRTC_FaLRTC_HaLRTC')
 rmpath('Completionall/SiLRTC_FaLRTC_HaLRTC/mylib')
%   save HSI_HaLRTC.mat output_image HaLRTC_PSNR HaLRTC_SSIM HaLRTC_SAM HaLRTC_time
end

%% t-SVD
% Zhang, Zemin, et al. "Novel methods for multilinear data completion and 
% de-noising based on tensor-SVD." Proceedings of the IEEE Conference on 
% Computer Vision and Pattern Recognition. 2014.
if Comparison_tSVD == 1
addpath('Completionall/tSVD')
addpath('Completionall/tSVD/proxFunctions')
addpath('Completionall/tSVD/solvers')
addpath('Completionall/tSVD/tSVD')
  alpha=1;
  maxiter=100; % maximum iteration
  rho=0.01;
  myNorm='tSVD_1'; % dont change for now
  A=diag(sparse(double(W(:)))); % sampling operator
  b=A * In_X(:); % available data
  tic
  output_image=tensor_cpl_admm( A , b , rho , alpha , size(In_X) , maxiter , myNorm , 0 );
  output_image=reshape(output_image,size(In_X));
  tSVD_time=toc;
[tSVD_PSNR,tSVD_SSIM,tSVD_SAM,tSVD_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:tSVD       ', ', MPSNR=' num2str(mean(tSVD_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(tSVD_SSIM),'%5.4f')  ',SAM=' num2str(tSVD_SAM,'%5.2f')...
           ',MQ=' num2str(mean(tSVD_MQ),'%5.4f') ',Time=' num2str(mean(tSVD_time),'%5.2f')]);
rmpath('Completionall/tSVD')
rmpath('Completionall/tSVD/proxFunctions')
rmpath('Completionall/tSVD/solvers')
rmpath('Completionall/tSVD/tSVD')
%  save HSI_tSVD.mat output_image tSVD_PSNR tSVD_SSIM tSVD_SAM tSVD_time
end
%%
if Comparison_LRTCTV == 1
addpath(genpath('Completionall/MFTV/lib'))
addpath('Completionall/MFTV')
% normalized data
if max(X(:))>1
X=X/max(X(:));
end

ratio = 0.1;
% R=AdapN_Rank(X,ratio);
R= [15,15,5];
Nway=[size(X,1), size(X,2), size(X,3)];
n1 = size(X,1); n2 = size(X,2); 
frames=size(X,3);
Y_tensorT = X;

known = find(W==1); data = Y_tensorT(known);
[known, id]= sort(known); data= data(id);
Y_tensor0= zeros(Nway); Y_tensor0(known)= data;
% Initialization of the factor matrices X and A
for n = 1:3
    coNway(n) = prod(Nway)/Nway(n);
end
for i = 1:3
    Y0{i} = Unfold(Y_tensor0,Nway,i);
    Y0{i} = Y0{i}';
    X0{i}= rand(coNway(i), R(i));
    A0{i}= rand(R(i),Nway(i));
end    
% Initialization of the parameters
opts=[];
opts.maxit=200;
% opts.Ytr= Y_tensorT;
opts.tol=1e-4;
alpha=[1,1,1];
opts.alpha = alpha / sum(alpha);
rho=0.1;
opts.rho1=rho;
opts.rho2=rho;
opts.rho3=rho;
opts.mu=1; 
opts.beta=10;
opts.initer=10;
opts.miter=20;
% Begin the comlpetion with MF_TV
        fprintf('\n');
        disp('Begin the comlpetion with TV')
        t0= tic;
        [output_image, ~, ~, Out]= LRTC_TV(Y0, data, A0, X0,Y_tensor0, Nway, known, opts, n1, n2);
        LRTCTV_time= toc(t0);
        [LRTCTV_PSNR,LRTCTV_SSIM,LRTCTV_SAM,LRTCTV_MQ] = evaluate(X,output_image,sz(1),sz(2));
        disp(['Method Name:LRTCTV      ', ', MPSNR=' num2str(mean(LRTCTV_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(LRTCTV_SSIM),'%5.4f')  ',SAM=' num2str(LRTCTV_SAM,'%5.2f')...
           ',MQ=' num2str(mean(LRTCTV_MQ),'%5.4f') ',Time=' num2str(mean(LRTCTV_time),'%5.2f')]);
       
%  save HSI_LRTCTV.mat output_image LRTCTV_PSNR LRTCTV_SSIM LRTCTV_SAM LRTCTV_time
end
%% TTSGD
% Zhao, Longhao Yuan, and Jianting Cao. "High-dimension 
% Tensor Completion via Gradient-based Optimization Under 
% Tensor-train Format." arXiv preprint arXiv:1804.01983 (2018).

if Comparison_TTSGD == 1
% addpath('Completionall/TTWOPT')
% addpath('Completionall/functions')
addpath('Completionall/TTWOPT')
% addpath('./Completionall/TTWOPT/additional_toolbox/tensor_toolbox/')
tic
 G_opted=TT_SGD(X.*double(W),double(W),'MaxIter',1e6,'Rank', 100*ones(2,1),'Tol', 1e-10);
[output_image]=coreten2tt(G_opted);
output_image(W==1)=X(W==1);
TTSGD_time=toc;
[TTSGD_PSNR,TTSGD_SSIM,TTSGD_SAM,TTSGD_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TTSGD       ', ', MPSNR=' num2str(mean(TTSGD_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TTSGD_SSIM),'%5.4f')  ',SAM=' num2str(TTSGD_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TTSGD_MQ),'%5.4f') ',Time=' num2str(mean(TTSGD_time),'%5.2f')]);
% rmpath('Completionall/TTWOPT')
% rmpath('Completionall/functions')
rmpath('Completionall/TTWOPT')
rmpath('./Completionall/TTWOPT/additional_toolbox/tensor_toolbox/')
%  save HSI_TTSGD.mat output_image TTSGD_PSNR TTSGD_SSIM TTSGD_SAM TTSGD_time
end

%% TR-ALS (PSNR 52.58)
% Wang, Wenqi, Vaneet Aggarwal, and Shuchin Aeron. 
% "Efficient low rank tensor ring completion." Rn 1.r1 (2017): 1.
if Comparison_TRALS == 1
addpath('Completionall/TR_ALS')
addpath('Completionall/TR_ALS/tensorlab')
addpath('Completionall/TR_ALS/TensorRing')   

 r_init=[20,20,15];
para_TR.disp = 1;
para_TR.r = r_init;   % Tensor Ring Rank
para_TR.max_tot=1e-5;
para_TR.max_iter=10;
tic
output_image = coreten2tr(TR_ALS(X.*double(W), double(W), para_TR));
output_image(W==1)=X(W==1);
TRALS_time=toc;
[TRALS_PSNR,TRALS_SSIM,TRALS_SAM,TRALS_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TRALS       ', ', MPSNR=' num2str(mean(TRALS_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TRALS_SSIM),'%5.4f')  ',SAM=' num2str(TRALS_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TRALS_MQ),'%5.4f') ',Time=' num2str(mean(TRALS_time),'%5.2f')]);

%   save HSI_TRALS.mat output_image TRALS_PSNR TRALS_SSIM TRALS_SAM TRALS_time

% TV
 output_image1=output_image;
 
 
 output_image=output_image1;
tic
param2.verbose=1;
param2.max_iter=100;
param2.verbose = 0;
    for i =1:size(output_image,3)  
      z = prox_TV(output_image(:,:,i),0.0001,param2);
      output_image(:,:,i) = z;  
    end
output_image(W==1)=X(W==1);
TV_t = toc;
%
[TRALS_PSNR,TRALS_SSIM,TRALS_SAM,TRALS_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TRALS       ', ', MPSNR=' num2str(mean(TRALS_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TRALS_SSIM),'%5.4f')  ',SAM=' num2str(TRALS_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TRALS_MQ),'%5.4f') ',Time=' num2str(mean(TRALS_time+TV_t),'%5.2f')]);
       
rmpath('Completionall/TR_ALS')
rmpath('Completionall/TR_ALS/tensorlab')
rmpath('Completionall/TR_ALS/TensorRing') 
%  save HSI_TVTRALS.mat output_image TRALS_PSNR TRALS_SSIM TRALS_SAM TRALS_time
end
%% TVTRC
% proposed
if Comparison_TVLRC == 1
%addpath('Completionall/TRLRF')
addpath('TVTR/TR_functions')
addpath('TVTR/tensor_toolbox')
addpath('TVTR/PROPACK')
addpath('TVTR/prox_operators')
addpath('TVTR')
PSNRval = zeros(9,9);
SSIMval = zeros(9,9);
Timeval = zeros(9,9);
Lam = [100,20,10,2,1,0.5,0.1];
for ii =5:5
    for jj=9:9
% r_init=[2*ii+1,2*ii+1,2*jj+1];
%  r_init=[15,15,7];
r_init=[15 15 7];maxiter=250;
tol=1e-6;
ro=1.01;%1.12
K=1e-6;
% Lambda=5.0;
Lambda = Lam(ii);
tic
[output_image,~]=TRLRF_CTV(X,W,r_init,maxiter,K,ro,Lambda,tol);
% [output_image,~]=TRC_ADMM(X,W,r_init,maxiter,K,ro,Lambda,tol);
% [output_image,~]=TRLRF_CTV_FFT(X,W,r_init,maxiter,K,ro,Lambda,tol);
output_image(W==1)=X(W==1);
TRLRF_time=toc;
[TRLRF_PSNR,TRLRF_SSIM,TRLRF_SAM,TRLRF_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TRLRF       ', ', MPSNR=' num2str(mean(TRLRF_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TRLRF_SSIM),'%5.4f')  ',SAM=' num2str(TRLRF_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TRLRF_MQ),'%5.4f') ',Time=' num2str(mean(TRLRF_time),'%5.2f')]);
PSNRval(ii,jj) = mean(TRLRF_PSNR);
SSIMval(ii,jj) = mean(TRLRF_SSIM);
Timeval(ii,jj) = mean(TRLRF_time);
    end
end
% save simu_TRLRF.mat output_image TRLRF_PSNR TRLRF_SSIM TRLRF_SAM TRLRF_time
end