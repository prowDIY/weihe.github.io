% demo completion
% clc;clear all
addpath('functions')
%% image load; include input noisy image X and mask image W
load('dubai_simu_case')
X = dubai_simu_ori(:,:,4:end);
W = logical(locdata);
In_X = dubai_simu_noise;
sz = size(X);

% load('dubai_real_band6.mat')
% X = double(indata);X = X(:,:,1:48)/max(X(:));
% W = logical(~locdata(:,:,1:48));
% In_X = X;
% sz = size(X);

X_ini=In_X;
% X_ini = init_X(In_X,double(W),size(X));


% sz = size(X);
% W = ones(sz);
% for i=1:sz(4)
%     tempx=X(:,:,:,i);
%     X(:,:,:,i)=tempx/max(tempx(:));
%     
%     Mask= class_sub(:,:,i);
%     Mask=(~Mask);
%     Mask= cat(3,Mask,Mask,Mask,Mask);
%     msz=size(Mask);
%     W(1:msz(1),1:msz(2),1:msz(3),i)= Mask;
% end
% W(:,:,:,[1,3])=1;
% 
% In_X = X.*W;
% sz=size(In_X);
% tempX =[];
% tempM=[];
% tempOri=[];
%     for count = 1:sz(4)
%         tempX = cat(3,tempX,In_X(:,:,:,count));
%         tempM = cat(3,tempM,W(:,:,:,count));
%         tempOri=cat(3,tempOri,X(:,:,:,count));
%     end
% X=tempOri;
% In_X=tempX;
% S = size(In_X);
% W=logical(tempM);
%% method selection
Comparison_LRSD = 0;
Comparison_TMac = 0;
Comparison_HaLRTC=0;
Comparison_tSVD = 0;
Comparison_LRTCTV = 0;
Comparison_TTSGD = 0;
Comparison_TRALS = 0;
Comparison_TVLRC =1;
%%
if Comparison_LRSD == 1;
%     addpath code_LRRSDS
    lambda = 1; % parameter for low rank regularization
%     lambda_s = 0.05; % parameter for sparse regularization
    Desired_rank = 5;
    AL_iter = 500;
    tic
[output_image] = LRSD(X_ini,W,lambda,Desired_rank,AL_iter);
output_image(W==1)=X(W==1);
% [output_image,~]=WH_LRMC(In_X.*W,W,300);
LRSD_time = toc;
[LRSD_PSNR,LRSD_SSIM,LRSD_SAM,LRSD_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:LRSD       ', ', MPSNR=' num2str(mean(LRSD_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(LRSD_SSIM),'%5.4f')  ',SAM=' num2str(LRSD_SAM,'%5.2f')...
           ',MQ=' num2str(mean(LRSD_MQ),'%5.4f') ',Time=' num2str(mean(LRSD_time),'%5.2f')]);
save dubai_real_band6_LRSD.mat output_image LRSD_time
%  save dubai_simu_LRSD.mat output_image LRSD_PSNR LRSD_SSIM LRSD_SAM LRSD_time
% LRSD_denoise = output_image;
end
%% TMac
% Xu, Yangyang, et al. "Parallel matrix factorization for low-rank
% tensor completion." arXiv preprint arXiv:1312.1254 (2013).

if Comparison_TMac == 1
addpath('Completionall/TMac')
    params.T=X_ini;
    params.Idx=double(W);
tic
output_image = run_tc_tmac(params);
output_image(W==1)=X(W==1);
TMac_time=toc;
[TMac_PSNR,TMac_SSIM,TMac_SAM,TMac_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TMac       ', ', MPSNR=' num2str(mean(TMac_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TMac_SSIM),'%5.4f')  ',SAM=' num2str(TMac_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TMac_MQ),'%5.4f') ',Time=' num2str(mean(TMac_time),'%5.2f')]);
rmpath('Completionall/TMac')
save dubai_real_band6_TMac.mat output_image TMac_time
%  save dubai_simu_TMac.mat output_image TMac_PSNR TMac_SSIM TMac_SAM TMac_time
end

%% HaLRTC
% Liu, Ji, et al. "Tensor completion for estimating missing values in visual data."
% IEEE transactions on pattern analysis and machine intelligence 35.1 (2013): 208-220.
if Comparison_HaLRTC == 1
addpath('Completionall/SiLRTC_FaLRTC_HaLRTC')
addpath('Completionall/SiLRTC_FaLRTC_HaLRTC/mylib')
N=ndims(X);
alpha=[1,1,10];
beta = 1e-6;
maxIter=500;
epsilon = 0;
Omega=(W==1);
mu = 1 * alpha ./ sqrt(size(X));
C =  0.6;
L0 = 1e-6;
tic
[output_image, errList] = HaLRTC(X_ini,Omega, alpha, beta, maxIter, epsilon);
HaLRTC_time=toc;
[HaLRTC_PSNR,HaLRTC_SSIM,HaLRTC_SAM,HaLRTC_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:HaLRTC       ', ', MPSNR=' num2str(mean(HaLRTC_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(HaLRTC_SSIM),'%5.4f')  ',SAM=' num2str(HaLRTC_SAM,'%5.2f')...
           ',MQ=' num2str(mean(HaLRTC_MQ),'%5.4f') ',Time=' num2str(mean(HaLRTC_time),'%5.2f')]);
 rmpath('Completionall/SiLRTC_FaLRTC_HaLRTC')
 rmpath('Completionall/SiLRTC_FaLRTC_HaLRTC/mylib')
 save dubai_real_band6_HaLRTC.mat output_image HaLRTC_time
%    save dubai_simu_HaLRTC.mat output_image HaLRTC_PSNR HaLRTC_SSIM HaLRTC_SAM HaLRTC_time
end

%% t-SVD
% Zhang, Zemin, et al. "Novel methods for multilinear data completion and 
% de-noising based on tensor-SVD." Proceedings of the IEEE Conference on 
% Computer Vision and Pattern Recognition. 2014.
if Comparison_tSVD == 1
addpath('Completionall/tSVD')
addpath('Completionall/tSVD/proxFunctions')
addpath('Completionall/tSVD/solvers')
addpath('Completionall/tSVD/tSVD')
  alpha=1;
  maxiter=150; % maximum iteration
  rho=0.05;
  myNorm='tSVD_1'; % dont change for now
  A=diag(sparse(double(W(:)))); % sampling operator
  b=A * X_ini(:); % available data
  tic
  output_image=tensor_cpl_admm( A , b , rho , alpha , size(In_X) , maxiter , myNorm , 0 );
  output_image=reshape(output_image,size(In_X));
  tSVD_time=toc;
[tSVD_PSNR,tSVD_SSIM,tSVD_SAM,tSVD_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:tSVD       ', ', MPSNR=' num2str(mean(tSVD_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(tSVD_SSIM),'%5.4f')  ',SAM=' num2str(tSVD_SAM,'%5.2f')...
           ',MQ=' num2str(mean(tSVD_MQ),'%5.4f') ',Time=' num2str(mean(tSVD_time),'%5.2f')]);
rmpath('Completionall/tSVD')
rmpath('Completionall/tSVD/proxFunctions')
rmpath('Completionall/tSVD/solvers')
rmpath('Completionall/tSVD/tSVD')
save dubai_real_band6_tSVD.mat tSVD_time output_image
%   save dubai_simu_tSVD.mat output_image tSVD_PSNR tSVD_SSIM tSVD_SAM tSVD_time
end
%%
if Comparison_LRTCTV == 1
addpath(genpath('Completionall/MFTV/lib'))
addpath('Completionall/MFTV')
% normalized data
if max(X(:))>1
X=X/max(X(:));
end

ratio = 0.1;
% R=AdapN_Rank(X,ratio);
R= [15,15,5];
Nway=[size(X,1), size(X,2), size(X,3)];
n1 = size(X,1); n2 = size(X,2); 
frames=size(X,3);
Y_tensorT = X;

known = find(W==1); data = Y_tensorT(known);
[known, id]= sort(known); data= data(id);
Y_tensor0= zeros(Nway);  
Y_tensor0(known)= data;
% Initialization of the factor matrices X and A
for n = 1:3
    coNway(n) = prod(Nway)/Nway(n);
end
for i = 1:3
    Y0{i} = Unfold(Y_tensor0,Nway,i);
    Y0{i} = Y0{i}';
    X0{i}= rand(coNway(i), R(i));
    A0{i}= rand(R(i),Nway(i));
end    
% Initialization of the parameters
opts=[];
opts.maxit=200;
% opts.Ytr= Y_tensorT;
opts.tol=1e-4;
alpha=[1,1,1];
opts.alpha = alpha / sum(alpha);
rho=0.1;
opts.rho1=rho;
opts.rho2=rho;
opts.rho3=rho;
opts.mu=1; 
opts.beta=10;
opts.initer=10;
opts.miter=20;
% Begin the comlpetion with MF_TV
        fprintf('\n');
        disp('Begin the comlpetion with TV')
        t0= tic;
        [output_image, ~, ~, Out]= LRTC_TV(Y0, data, A0, X0,Y_tensor0, Nway, known, opts, n1, n2);
        LRTCTV_time= toc(t0);
        [LRTCTV_PSNR,LRTCTV_SSIM,LRTCTV_SAM,LRTCTV_MQ] = evaluate(X,output_image,sz(1),sz(2));
        disp(['Method Name:LRTCTV      ', ', MPSNR=' num2str(mean(LRTCTV_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(LRTCTV_SSIM),'%5.4f')  ',SAM=' num2str(LRTCTV_SAM,'%5.2f')...
           ',MQ=' num2str(mean(LRTCTV_MQ),'%5.4f') ',Time=' num2str(mean(LRTCTV_time),'%5.2f')]);
save dubai_real_band6_LRTCTV.mat LRTCTV_time output_image
%   save dubai_simu_LRTCTV.mat output_image LRTCTV_PSNR LRTCTV_SSIM LRTCTV_SAM LRTCTV_time
end
%% TTSGD
% Zhao, Longhao Yuan, and Jianting Cao. "High-dimension 
% Tensor Completion via Gradient-based Optimization Under 
% Tensor-train Format." arXiv preprint arXiv:1804.01983 (2018).

if Comparison_TTSGD == 1
 addpath('Completionall/TTWOPT')
 %addpath('Completionall/functions')
 addpath('./Completionall/TTWOPT/additional_toolbox/tensor_toolbox/')
tic
 G_opted=TT_SGD(X_ini,double(W),'MaxIter',1e6,'Rank', 150*ones(2,1),'Tol', 1e-10);
[output_image]=coreten2tt(G_opted);
output_image(W==1)=X(W==1);
TTSGD_time=toc;
[TTSGD_PSNR,TTSGD_SSIM,TTSGD_SAM,TTSGD_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TTSGD       ', ', MPSNR=' num2str(mean(TTSGD_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TTSGD_SSIM),'%5.4f')  ',SAM=' num2str(TTSGD_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TTSGD_MQ),'%5.4f') ',Time=' num2str(mean(TTSGD_time),'%5.2f')]);
% rmpath('Completionall/TTWOPT')
% rmpath('Completionall/functions')
rmpath('Completionall/TTWOPT')
% rmpath('./Completionall/TTWOPT/additional_toolbox/tensor_toolbox/')
%  save dubai_real_band6_TTSGD.mat output_image TTSGD_time
%  for i =31:6:48;figure();imshow(double(output_image(:,:,[i+2 i+1 i])),[]);end
%   save dubai_simu_TTSGD.mat output_image TTSGD_PSNR TTSGD_SSIM TTSGD_SAM TTSGD_time
end

%% TR-ALS (PSNR 52.58)
% Wang, Wenqi, Vaneet Aggarwal, and Shuchin Aeron. 
% "Efficient low rank tensor ring completion." Rn 1.r1 (2017): 1.
if Comparison_TRALS == 1
addpath('Completionall/TR_ALS')
addpath('Completionall/TR_ALS/tensorlab')
addpath('Completionall/TR_ALS/TensorRing')   
addpath('prox_operators')
 r_init=[17,17,8];
para_TR.disp = 1;
para_TR.r = r_init;   % Tensor Ring Rank
para_TR.max_tot=1e-5;
para_TR.max_iter=15;
tic
output_image = coreten2tr(TR_ALS(X_ini, double(W), para_TR));
output_image(W==1)=X(W==1);
TRALS_time=toc;
[TRALS_PSNR,TRALS_SSIM,TRALS_SAM,TRALS_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TRALS       ', ', MPSNR=' num2str(mean(TRALS_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TRALS_SSIM),'%5.4f')  ',SAM=' num2str(TRALS_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TRALS_MQ),'%5.4f') ',Time=' num2str(mean(TRALS_time),'%5.2f')]);
% save dubai_real_band6_TR_ALS.mat output_image TRALS_time
% for i =31:6:48;figure();imshow(double(output_image(:,:,[i+2 i+1 i])),[]);end
% save dubai_simu_TRALS.mat output_image TRALS_PSNR TRALS_SSIM TRALS_SAM TRALS_time

% TV
 output_image1=output_image;
 
 
 output_image=output_image1;
tic
param2.verbose=1;
param2.max_iter=100;
param2.verbose = 0;
    for i =1:size(output_image,3)  
      z = prox_TV(output_image(:,:,i),0.05,param2);
      output_image(:,:,i) = z;  
    end
output_image(W==1)=X(W==1);
TV_t = toc;
%
[TRALS_PSNR,TRALS_SSIM,TRALS_SAM,TRALS_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TRALS       ', ', MPSNR=' num2str(mean(TRALS_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TRALS_SSIM),'%5.4f')  ',SAM=' num2str(TRALS_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TRALS_MQ),'%5.4f') ',Time=' num2str(mean(TRALS_time+TV_t),'%5.2f')]);
       
rmpath('Completionall/TR_ALS')
rmpath('Completionall/TR_ALS/tensorlab')
rmpath('Completionall/TR_ALS/TensorRing') 
% save dubai_real_band6_TVTR_ALS.mat output_image TRALS_time
% for i =31:6:48;figure();imshow(double(output_image(:,:,[i+2 i+1 i])),[]);end
%   save dubai_simu_TVTRALS.mat output_image TRALS_PSNR TRALS_SSIM TRALS_SAM TRALS_time
end
%% TVTRC
%Yuan, Longhao, et al. "Higher-dimension Tensor Completion via Low-rank
%Tensor Ring Decomposition." arXiv preprint arXiv:1807.01589 (2018).
if Comparison_TVLRC == 1
addpath('Completionall/TRLRF')
addpath('Completionall/TRLRF/TR_functions')
addpath('Completionall\TTWOPT\additional_toolbox\tensor_toolbox')
addpath('PROPACK')
addpath('prox_operators')
PSNRval = zeros(9,7);
SSIMval = zeros(9,7);
Timeval = zeros(9,7);
% Lam = [100,20,10,2,1,0.5,0.1];
% for ii =1:9
%     for jj=1:1
% r_init=[2*ii+1,2*ii+1,2*jj+1];
%  r_init=[15 15 10];
r_init=[17,17,8];
maxiter=100;
tol=1e-6;
ro=1.01;%1.12
K=1e-6;
Lambda=2;
% Lambda = Lam(ii);
tic
[output_image,ABV,conv]=TRLRF_CTV(X,W,r_init,maxiter,K,ro,Lambda,tol);
% [output_image,~]=TRC_ADMM(X,W,r_init,maxiter,K,ro,Lambda,tol);
% [output_image,~]=TRLRF_CTV_FFT(X,W,r_init,maxiter,K,ro,Lambda,tol);
output_image(W==1)=X(W==1);
TRLRF_time=toc;
[TRLRF_PSNR,TRLRF_SSIM,TRLRF_SAM,TRLRF_MQ] = evaluate(X,output_image,sz(1),sz(2));
disp(['Method Name:TRLRF       ', ', MPSNR=' num2str(mean(TRLRF_PSNR),'%5.2f')  ...
           ',MSSIM = ' num2str(mean(TRLRF_SSIM),'%5.4f')  ',SAM=' num2str(TRLRF_SAM,'%5.2f')...
           ',MQ=' num2str(mean(TRLRF_MQ),'%5.4f') ',Time=' num2str(mean(TRLRF_time),'%5.2f')]);
% save dubai_real_band6_TVTR_LRF.mat output_image TRLRF_time
% for i =31:6:48;figure();imshow(double(output_image(:,:,[i+2 i+1 i])),[]);end
% save dubai_simu_TRLRF.mat output_image TRLRF_PSNR TRLRF_SSIM TRLRF_SAM TRLRF_time
% PSNRval(ii,jj) = mean(TRLRF_PSNR);
% SSIMval(ii,jj) = mean(TRLRF_SSIM);
% Timeval(ii,jj) = mean(TRLRF_time);
%     end
% end

end